﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PRConsumerApi.Data;
using PRConsumerApi.MessageQueue;
using PRConsumerApi.Models;

namespace PRWebApp.Controllers
{
    //TODO: Use the PRConsumerApi/Services/PropertyRepairsService.cs instead of the DbContext.
    public class PropertyRepairsController : Controller
    {
        private readonly PropertyRepairsDbContext _context;
        private readonly ILogger<PropertyRepair> _logger;
        private readonly IRabbitMqConsumer _rabbitMqConsumer;

        public PropertyRepairsController(PropertyRepairsDbContext context, ILogger<PropertyRepair> logger, IRabbitMqConsumer rabbitMqConsumer)
        {
            _context = context;
            _logger = logger;
            _rabbitMqConsumer = rabbitMqConsumer;
        }

        // GET: PropertyRepairs
        public async Task<IActionResult> Index()
        {
            var propertyRepairsDbContext = _context.PropertyRepairs.Include(p => p.Owner).Include(p => p.Property);
            return View(await propertyRepairsDbContext.ToListAsync());
        }

        // GET: Peek available PropertyRepairs from Message Queue
        public async Task<IActionResult> QueueMessages()
        {
            return View(_rabbitMqConsumer.PeekRepairMessagesFromQueue());
        }


        // GET: PropertyRepairs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var propertyRepair = await _context.PropertyRepairs
                .Include(p => p.Owner)
                .Include(p => p.Property)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (propertyRepair == null)
            {
                return NotFound();
            }

            return View(propertyRepair);
        }

        // GET: PropertyRepairs/Create
        public IActionResult Create()
        {
            ViewData["OwnerId"] = new SelectList(_context.Owners, "Id", "Email");
            ViewData["PropertyId"] = new SelectList(_context.Properties, "Id", "Address");
            return View();
        }

        // POST: PropertyRepairs/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,OwnerId,PropertyId,Description,Type,RequestDate,CompletionDate")] PropertyRepair propertyRepair)
        {
            if (ModelState.IsValid)
            {
                _context.Add(propertyRepair);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["OwnerId"] = new SelectList(_context.Owners, "Id", "Email", propertyRepair.OwnerId);
            ViewData["PropertyId"] = new SelectList(_context.Properties, "Id", "Address", propertyRepair.PropertyId);
            return View(propertyRepair);
        }

        // GET: PropertyRepairs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var propertyRepair = await _context.PropertyRepairs.FindAsync(id);
            if (propertyRepair == null)
            {
                return NotFound();
            }
            ViewData["OwnerId"] = new SelectList(_context.Owners, "Id", "Email", propertyRepair.OwnerId);
            ViewData["PropertyId"] = new SelectList(_context.Properties, "Id", "Address", propertyRepair.PropertyId);
            return View(propertyRepair);
        }

        // POST: PropertyRepairs/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,OwnerId,PropertyId,Description,Type,RequestDate,CompletionDate")] PropertyRepair propertyRepair)
        {
            if (id != propertyRepair.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(propertyRepair);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PropertyRepairExists(propertyRepair.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["OwnerId"] = new SelectList(_context.Owners, "Id", "Email", propertyRepair.OwnerId);
            ViewData["PropertyId"] = new SelectList(_context.Properties, "Id", "Address", propertyRepair.PropertyId);
            return View(propertyRepair);
        }

        // GET: PropertyRepairs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var propertyRepair = await _context.PropertyRepairs
                .Include(p => p.Owner)
                .Include(p => p.Property)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (propertyRepair == null)
            {
                return NotFound();
            }

            return View(propertyRepair);
        }

        // POST: PropertyRepairs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var propertyRepair = await _context.PropertyRepairs.FindAsync(id);
            if (propertyRepair != null)
            {
                _context.PropertyRepairs.Remove(propertyRepair);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PropertyRepairExists(int id)
        {
            return _context.PropertyRepairs.Any(e => e.Id == id);
        }
    }
}
