﻿namespace PRPublisherApi.MessageQueue
{
    public interface IRabbitMqPublisher
    {
        public void PutRepairMessage<T>(T message);
    }
}
