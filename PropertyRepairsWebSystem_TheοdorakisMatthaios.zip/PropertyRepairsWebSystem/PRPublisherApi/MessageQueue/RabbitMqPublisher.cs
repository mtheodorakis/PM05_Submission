﻿using Microsoft.AspNetCore.Connections;
using System.Text;
using RabbitMQ.Client;
using Newtonsoft.Json;

namespace PRPublisherApi.MessageQueue
{
    public class RabbitMqPublisher : IRabbitMqPublisher
    {
        public void PutRepairMessage<T>(T message)
        {
            // Specify the Rabbit MQ Server that runs from a docker image.
            //TODO: Make RabbitMQ username and password configurable.
            var factory = new ConnectionFactory
            {
                HostName = "localhost",
                UserName = "guest",     // Replace with your RabbitMQ username
                Password = "guest"      // Replace with your RabbitMQ password
            };
            // Create the RabbitMQ connection.
            var connection = factory.CreateConnection();
            // Create the channel with session and model.
            using var channel = connection.CreateModel();
            // Declare the queue and specify its name and basic properties.
            channel.QueueDeclare(queue: "property_repairs",
                                //durable: true,
                                exclusive: false,
                                autoDelete: false,
                                arguments: null);

            // Serialize the message.
            var json = JsonConvert.SerializeObject(message);
            var body = Encoding.UTF8.GetBytes(json);
            // Put the data in the queue.
            channel.BasicPublish(exchange: string.Empty, routingKey: "property_repairs", body: body);
        }
    }
}
