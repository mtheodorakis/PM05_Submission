﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PRConsumerApi.Models;

namespace PRConsumerApi.Data
{
    public class PropertyRepairsDbContext: DbContext
    {
        protected readonly IConfiguration Configuration;

        public PropertyRepairsDbContext(IConfiguration configuration, DbContextOptions<PropertyRepairsDbContext> options) : base(options)
        {
            Configuration = configuration;
        }

        public DbSet<Owner> Owners { get; set; }
        public DbSet<Property> Properties { get; set; }
        public DbSet<PropertyRepair> PropertyRepairs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Owner>().ToTable("Owner");
            modelBuilder.Entity<Property>().ToTable("Property");
            modelBuilder.Entity<PropertyRepair>().ToTable("PropertyRepair");
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }
        public DbSet<PRConsumerApi.Models.PropertyRepairDto> PropertyRepairDto { get; set; } = default!;
    }
}
