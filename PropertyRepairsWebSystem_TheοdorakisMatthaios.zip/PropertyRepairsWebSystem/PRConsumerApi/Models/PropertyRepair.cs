﻿namespace PRConsumerApi.Models
{
    public class PropertyRepair
    {
        public int Id { get; set; }

        public int OwnerId { get; set; }

        public int PropertyId { get; set; }
        public string Description { get; set; } = string.Empty;
        public RepairType Type { get; set; } = RepairType.Other;
        public DateTime RequestDate { get; set; } = DateTime.Now;
        public DateTime? CompletionDate { get; set; }

        // Full Info
        public Owner? Owner { get; set; }
        public Property? Property { get; set; }
    }
}
