﻿using System.ComponentModel.DataAnnotations;

namespace PRConsumerApi.Models
{
    public class Owner
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string FullName { get; set; }
        [Required]
        public string Email { get; set; }
        public string Phone { get; set; }
    }
}
