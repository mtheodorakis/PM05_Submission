﻿namespace PRConsumerApi.Models
{
    // Create an enumeration for the property repair type.
    public enum RepairType
    {
        Other,
        Painting,
        Insulation,
        Frames,
        Plumbing,
        ElectricalWork
    }
}
