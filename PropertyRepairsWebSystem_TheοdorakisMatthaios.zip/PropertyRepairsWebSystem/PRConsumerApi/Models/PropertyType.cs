﻿namespace PRConsumerApi.Models
{
    // Create an enumeration for the property type.
    public enum PropertyType
    {
        Other,
        House,
        Apartment,
        Store
    }
}
