﻿namespace PRConsumerApi.Models
{
    public class Property
    {
        public int Id { get; set; }
        public Owner OwnerId { get; set; }
        /// <summary>
        /// Property location: full address including city, state, and zip code
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// The date that the agreement to manage the property was finalized.
        /// </summary>
        public DateTime AgreementDate { get; set; } = DateTime.Now;
        /// <summary>
        /// Information for the property
        /// </summary>
        public string Description { get; set; } = string.Empty;
        /// <summary>
        /// E.g. houses, apartments, stores, etc.
        /// </summary>
        public PropertyType Type{ get; set; } = PropertyType.Other;


        public List<PropertyRepair>? Repairs { get; set; }

        /// <summary>The number of all items in the order.</summary>
        public int TotalRepairs => Repairs?.Count() ?? 0;

    }
}
