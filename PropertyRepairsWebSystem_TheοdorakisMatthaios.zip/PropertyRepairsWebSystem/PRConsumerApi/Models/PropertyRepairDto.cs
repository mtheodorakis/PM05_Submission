﻿namespace PRConsumerApi.Models
{
    public class PropertyRepairDto
    {
        public int Id { get; set; }
        public string OwnerName { get; set; }
        public string OwnerEmail { get; set; }
        public string OwnerPhone { get; set; }
        public string PropertyLocation { get; set; }
        public string Description { get; set; } = string.Empty;
        public RepairType Type { get; set; } = RepairType.Other;
        public DateTime RequestDate { get; set; } = DateTime.Now;
        public DateTime? CompletionDate { get; set; }
    }
}
