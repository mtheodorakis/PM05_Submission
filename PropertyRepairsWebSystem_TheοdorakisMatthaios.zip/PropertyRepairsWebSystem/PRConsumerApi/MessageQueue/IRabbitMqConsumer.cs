﻿using PRConsumerApi.Models;

namespace PRConsumerApi.MessageQueue
{
    public interface IRabbitMqConsumer
    {
        public List<PropertyRepairDto> GetRepairMessagesFromQueue();
        public List<PropertyRepairDto> PeekRepairMessagesFromQueue();
    }
}
