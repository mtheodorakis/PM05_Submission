﻿using RabbitMQ.Client.Events;
using RabbitMQ.Client;
using PRConsumerApi.Models;
using System.Text;
using Newtonsoft.Json;

namespace PRConsumerApi.MessageQueue
{
    public class RabbitMqConsumer : IRabbitMqConsumer
    {
        private readonly ILogger<PropertyRepairDto> _logger;
        private ManualResetEvent messageProcessingComplete = new ManualResetEvent(false);

        public RabbitMqConsumer(ILogger<PropertyRepairDto> logger)
        {
            _logger = logger;
        }

        private List<PropertyRepairDto> ReadRepairMessagesFromQueue(bool removeAfterRead = true)
        {
            var newPropertyRepairs = new List<PropertyRepairDto>();

            // Specify the Rabbit MQ Server that runs from a docker image.
            var factory = new ConnectionFactory { HostName = "localhost" };
            // Create the RabbitMQ connection.
            using var connection = factory.CreateConnection();
            // Create the channel with session and model.
            using var channel = connection.CreateModel();
            // Declare the queue and specify its name and basic properties.
            channel.QueueDeclare("property_repairs",
                                exclusive: false,
                                autoDelete: false,
                                arguments: null);

            // Set Event object which listen message from the channel that is sent by publisher.
            var consumer = new EventingBasicConsumer(channel);

            // Get the new messages from the queue.
            consumer.Received += (model, eventArgs) =>
            {
                var body = eventArgs.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);
                try
                {
                    PropertyRepairDto? repair = JsonConvert.DeserializeObject<PropertyRepairDto>(message);
                    _logger.LogInformation($"Received message: {message}");
                    if (repair != null)
                        newPropertyRepairs.Add(repair);
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Error while receiving message: {ex.Message}");
                }

                if (removeAfterRead)
                {
                    // Check if all expected messages are processed and then signal that message processing is complete.
                    messageProcessingComplete.Set();
                }
            };
            channel.BasicConsume(queue: "property_repairs", autoAck: true, consumer: consumer);

            // Wait before processing the queue or use the timeout in case the queue is empty.
            //TODO Make the timeout configurable.
            bool messagesProcessed = messageProcessingComplete.WaitOne(TimeSpan.FromSeconds(3));
            if (!messagesProcessed)
            {
                return newPropertyRepairs;
            }

            return newPropertyRepairs;
        }


        public List<PropertyRepairDto> GetRepairMessagesFromQueue()
        {
            return ReadRepairMessagesFromQueue(true);
        }

        public List<PropertyRepairDto> PeekRepairMessagesFromQueue()
        {
            return ReadRepairMessagesFromQueue(false);
        }
    }
}
