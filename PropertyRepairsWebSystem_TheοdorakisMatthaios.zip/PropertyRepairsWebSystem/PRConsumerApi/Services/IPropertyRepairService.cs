﻿using PRConsumerApi.Models;
using System.Net;

namespace PRConsumerApi.Services
{
    public interface IPropertyRepairService
    {
        Task<IEnumerable<PropertyRepair>> GetAllPropertyRepairsAsync();
        Task<PropertyRepair> GetPropertyRepairAsync(int? id);
        /// <summary>
        /// Uses the Dto
        /// </summary>
        Task<bool> CreatePropertyRepairAsync(PropertyRepairDto PropertyRepairDto);
        Task<bool> CreatePropertyRepairAsync(PropertyRepair PropertyRepair);
        Task<bool> DeletePropertyRepairAsync(int id);
        /// <summary>
        /// Uses the Dto
        /// </summary>
        Task<bool> UpdatePropertyRepairAsync(PropertyRepairDto PropertyRepairDto);
        Task<bool> UpdatePropertyRepairAsync(PropertyRepair PropertyRepair);
    }
}
