﻿using PRConsumerApi.Models;
using System.Net;

namespace PRConsumerApi.Services
{
    public interface IOwnerService
    {
        Task<IEnumerable<Owner>> GetAllOwnersAsync();
        Task<Owner> GetOwnerAsync(int? id);
        Task<bool> CreateOwnerAsync(Owner Owner);
        Task<bool> DeleteOwnerAsync(int id);
        Task<bool> UpdateOwnerAsync(Owner Owner);
    }
}
