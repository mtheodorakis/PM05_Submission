﻿using PRConsumerApi.Models;
using System.Net;

namespace PRConsumerApi.Services
{
    public interface IPropertyService
    {
        Task<IEnumerable<Property>> GetAllPropertysAsync();
        Task<Property> GetPropertyAsync(int? id);
        Task<bool> CreatePropertyAsync(Property Property);
        Task<bool> DeletePropertyAsync(int id);
        Task<bool> UpdatePropertyAsync(Property Property);
    }
}
