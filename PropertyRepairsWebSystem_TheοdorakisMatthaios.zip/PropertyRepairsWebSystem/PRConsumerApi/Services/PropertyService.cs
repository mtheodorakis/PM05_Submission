﻿using PRConsumerApi.Models;

namespace PRConsumerApi.Services
{
    public class PropertyService : IPropertyService
    {
        Task<bool> IPropertyService.CreatePropertyAsync(Property Property)
        {
            throw new NotImplementedException();
        }

        Task<bool> IPropertyService.DeletePropertyAsync(int id)
        {
            throw new NotImplementedException();
        }

        Task<IEnumerable<Property>> IPropertyService.GetAllPropertysAsync()
        {
            throw new NotImplementedException();
        }

        Task<Property> IPropertyService.GetPropertyAsync(int? id)
        {
            throw new NotImplementedException();
        }

        Task<bool> IPropertyService.UpdatePropertyAsync(Property Property)
        {
            throw new NotImplementedException();
        }
    }
}
