﻿using Microsoft.EntityFrameworkCore;
using PRConsumerApi.Data;
using PRConsumerApi.Models;

namespace PRConsumerApi.Services
{
    public class PropertyRepairService : IPropertyRepairService
    {
        private readonly PropertyRepairsDbContext _context;
        private readonly ILogger<PropertyRepair> _logger;

        public PropertyRepairService(PropertyRepairsDbContext context, ILogger<PropertyRepair> logger)
        {
            _context = context;
            _logger = logger;

            if (_context.PropertyRepairs == null)
            {
                var ex = new ArgumentNullException("Entity set 'PropertyRepairsDbContext.PropertyRepairs' is null.");
                _logger.LogError(ex.Message);
                throw ex;
            }
        }


        public async Task<IEnumerable<PropertyRepair>> GetAllPropertyRepairsAsync()
        {
            try
            {
                return await _context.PropertyRepairs.Include(pr => pr.Owner).Include(pr => pr.Property).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return new List<PropertyRepair>();
        }


        public async Task<PropertyRepair> GetPropertyRepairAsync(int? id)
        {
            try
            {
                return await _context.PropertyRepairs.FirstOrDefaultAsync(pr => pr.Id == id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return null;
        }


        public async Task<bool> CreatePropertyRepairAsync(PropertyRepair PropertyRepair)
        {
            try
            {
                _context.PropertyRepairs.Add(PropertyRepair);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return false;
        }
        public async Task<bool> CreatePropertyRepairAsync(PropertyRepairDto PropertyRepairDto)
        {
            try
            {
                var propertyRepair = await ConvertPropertyRepairDto(PropertyRepairDto);
                if (propertyRepair != null)
                {
                    return await CreatePropertyRepairAsync(propertyRepair);
                }
                else
                {
                    _logger.LogError("PropertyRepairDto could not be converted to PropertyRepair.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return false;
        }

        public async Task<bool> DeletePropertyRepairAsync(int id)
        {
            try
            {
                var repair = await _context.PropertyRepairs.FindAsync(id);
                if (repair != null)
                {
                    _context.PropertyRepairs.Remove(repair);
                    await _context.SaveChangesAsync();
                    return true;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return false;
        }


        public async Task<bool> UpdatePropertyRepairAsync(PropertyRepairDto PropertyRepairDto)
        {
            try
            {
                var propertyRepair = await ConvertPropertyRepairDto(PropertyRepairDto);
                if (propertyRepair != null)
                {
                    return await UpdatePropertyRepairAsync(propertyRepair);
                }
                else
                {
                    _logger.LogError("PropertyRepairDto could not be converted to PropertyRepair.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return false;
        }

        public async Task<bool> UpdatePropertyRepairAsync(PropertyRepair PropertyRepair)
        {
            try
            {
                _context.Update(PropertyRepair);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException dbUCE)
            {
                if (_context.PropertyRepairs.Any(pr => pr.Id == PropertyRepair.Id))
                {
                    _logger.LogError(dbUCE.Message);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return false;
        }


        //TODO Write it as a static converter method for the PropertyRepairs class.
        private async Task<PropertyRepair> ConvertPropertyRepairDto(PropertyRepairDto PropertyRepairDto)
        {
            try 
            {
                Owner owner = await _context.Owners.FirstOrDefaultAsync(o => o.Email == PropertyRepairDto.OwnerEmail);
                Property property = await _context.Properties.FirstOrDefaultAsync(p => p.Address == PropertyRepairDto.PropertyLocation);
                return new PropertyRepair
                {
                    OwnerId = owner.Id,
                    PropertyId = property.Id,
                    Description = PropertyRepairDto.Description,
                    Type = PropertyRepairDto.Type,
                    RequestDate = PropertyRepairDto.RequestDate,
                    CompletionDate = PropertyRepairDto.CompletionDate
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return null;
        }
    }
}
