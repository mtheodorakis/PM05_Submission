﻿using PRConsumerApi.Models;

namespace PRConsumerApi.Services
{
    public class OwnerService : IOwnerService
    {
        Task<bool> IOwnerService.CreateOwnerAsync(Owner Owner)
        {
            throw new NotImplementedException();
        }

        Task<bool> IOwnerService.DeleteOwnerAsync(int id)
        {
            throw new NotImplementedException();
        }

        Task<IEnumerable<Owner>> IOwnerService.GetAllOwnersAsync()
        {
            throw new NotImplementedException();
        }

        Task<Owner> IOwnerService.GetOwnerAsync(int? id)
        {
            throw new NotImplementedException();
        }

        Task<bool> IOwnerService.UpdateOwnerAsync(Owner Owner)
        {
            throw new NotImplementedException();
        }
    }
}
