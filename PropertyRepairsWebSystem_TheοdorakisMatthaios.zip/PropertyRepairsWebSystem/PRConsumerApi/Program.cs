﻿using Microsoft.EntityFrameworkCore;
using PRConsumerApi.Data;
using PRConsumerApi.MessageQueue;
using PRConsumerApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Logging
builder.Services.AddLogging(configure =>
{
    configure.AddConsole();
    configure.AddDebug();
});

// DBContext
builder.Services.AddDbContext<PropertyRepairsDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("PropertyRepairsDBLocal"),
                         (optionsAction => optionsAction.MigrationsAssembly("PRConsumerApi")));
    options.EnableSensitiveDataLogging();
});

// Message Queue
builder.Services.AddScoped<IRabbitMqConsumer, RabbitMqConsumer>();

// Add services to the container.
builder.Services.AddScoped<IOwnerService, OwnerService>();
builder.Services.AddScoped<IPropertyService, PropertyService>();
builder.Services.AddScoped<IPropertyRepairService, PropertyRepairService>();


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
