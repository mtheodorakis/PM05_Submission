﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PRConsumerApi.Data;
using PRConsumerApi.Models;
using PRConsumerApi.Services;

namespace PRConsumerApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PropertyRepairsController : ControllerBase
    {
        //private readonly PropertyRepairsDbContext _context;
        private readonly IPropertyRepairService _propertyRepairService;
        /// <summary>
        /// Logger for errors only
        /// </summary>
        private readonly ILogger<PropertyRepair> _errorLogger;

        public PropertyRepairsController(IPropertyRepairService propertyRepairService, ILogger<PropertyRepair> logger)
        {
            _propertyRepairService = propertyRepairService;
            _errorLogger = logger;
        }


        // GET: api/PropertyRepairs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PropertyRepair>>> GetPropertyRepairs()
        {
            var repairs = await _propertyRepairService.GetAllPropertyRepairsAsync();
            if (repairs == null)
            {
                return NotFound();
            }
            return Ok(repairs);
        }

        // GET: api/PropertyRepairs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PropertyRepair>> GetPropertyRepair(int id)
        {
            var propertyRepair = await _propertyRepairService.GetPropertyRepairAsync(id);
            if (propertyRepair == null)
            {
                return NotFound();
            }
            return propertyRepair;
        }

        // PUT: api/PropertyRepairs/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPropertyRepair(int id, PropertyRepair propertyRepair)
        {
            if (id != propertyRepair.Id)
            {
                return BadRequest();
            }
            var result = await _propertyRepairService.UpdatePropertyRepairAsync(propertyRepair);
            if (!result)
            {
                _errorLogger.LogError($"PropertyRepair with id {propertyRepair.Id} could not be updated.");
                return Problem();
            }
            return Ok(propertyRepair);
        }

        // POST: api/PropertyRepairs
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<PropertyRepair>> PostPropertyRepair(PropertyRepair propertyRepair)
        {
            var result = await _propertyRepairService.CreatePropertyRepairAsync(propertyRepair); 
            if (!result)
            {
                _errorLogger.LogError($"PropertyRepair with id {propertyRepair.Id} could not be created.");
                return Problem();
            }
            return Ok(propertyRepair);
        }

        // DELETE: api/PropertyRepairs/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePropertyRepair(int id)
        {
            var result = await _propertyRepairService.DeletePropertyRepairAsync(id);
            if (!result)
            {
                _errorLogger.LogError($"PropertyRepair with id {id} could not be deleted.");
                return Problem();
            }
            return Ok(id);
        }

        private bool PropertyRepairExists(int id)
        {
            return _propertyRepairService.GetPropertyRepairAsync(id) != null;
        }
    }
}
