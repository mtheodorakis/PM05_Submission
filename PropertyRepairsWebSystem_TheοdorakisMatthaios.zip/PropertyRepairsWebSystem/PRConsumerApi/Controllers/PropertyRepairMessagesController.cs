﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PRConsumerApi.MessageQueue;
using PRConsumerApi.Models;
using PRConsumerApi.Services;

namespace PRConsumerApi.Controllers
{
    public class PropertyRepairMessagesController : Controller
    {
        private readonly IPropertyRepairService _propertyRepairsService;
        private readonly IRabbitMqConsumer _rabbitMqConsumer;

        public PropertyRepairMessagesController(IPropertyRepairService propertyRepairsService, IRabbitMqConsumer rabbitMqConsumer)
        {
            _propertyRepairsService = propertyRepairsService;
            _rabbitMqConsumer = rabbitMqConsumer;
        }


        [HttpGet("PropertyRepairlist")]
        public async Task<IEnumerable<PropertyRepair>> PropertyRepairListAsync()
        {
            var PropertyRepairList = await _propertyRepairsService.GetAllPropertyRepairsAsync();
            return PropertyRepairList;
        }

        [HttpGet("getPropertyRepairbyid/{id}")]
        public async Task<PropertyRepair?> GetPropertyRepairById(int Id)
        {
            return await _propertyRepairsService.GetPropertyRepairAsync(Id);
        }

        [HttpPost("addPropertyRepairs")]
        public async Task<int> AddPropertyRepair(PropertyRepair PropertyRepair)
        {
            // Retrieve messages from the queue
            var repairs = _rabbitMqConsumer.GetRepairMessagesFromQueue();

            int added = 0;
            foreach(var repair in repairs)
            {
                try
                {
                    // Add the repair to the database.
                    await _propertyRepairsService.CreatePropertyRepairAsync(repair);
                    added++;
                }
                catch (Exception ex)
                {
                    // Log the error.
                    Console.WriteLine(ex.Message);
                }
            }
            return added;
        }

        [HttpPut("updatePropertyRepair")]
        public async Task<bool?> UpdatePropertyRepair(PropertyRepair PropertyRepair)
        {
            return await _propertyRepairsService.UpdatePropertyRepairAsync(PropertyRepair);
        }

        [HttpDelete("deletePropertyRepair/{id}")]
        public async Task<bool> DeletePropertyRepair(int Id)
        {
            return await _propertyRepairsService.DeletePropertyRepairAsync(Id);
        }
    }
}
